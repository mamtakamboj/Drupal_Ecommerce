Metatag Context
---------------
This module is provides a Metatag reaction for Context [1], thus allowing meta
tags to be assigned to specific paths and other conditions.

Configuration can controlled via the normal Context UI module or the new admin
page available at: admin/config/search/metatags/context


Credits
------------------------------------------------------------------------------
This module is based on the Context Metadata [2] module. The initial
development was by Marcin Pajdzik [3] (sponsored by Dennis Publishing [4]).


References
------------------------------------------------------------------------------
1: http://drupal.org/project/context
2: http://drupal.org/project/context_metadata
3: http://drupal.org/user/160555
4: http://www.dennis.co.uk/
