Metatag: Views
----------------
This module adds support for meta tag configuration for Views pages.

Configuration is done within the "Metatag" section of the Page Settings in
the Views UI configuration page.


Credits / Contact
--------------------------------------------------------------------------------
Originally developed by Dave Reid [1].


References
--------------------------------------------------------------------------------
1: http://drupal.org/user/53892
